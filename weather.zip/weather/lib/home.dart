import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:weather/additional.dart';
import 'package:http/http.dart' as http;

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  Future<Map<String, dynamic>> fetchWeatherData() async {
    try {
      String url =
          'https://api.openweathermap.org/data/2.5/forecast?q=Multan&units=metric&appid=a8988f52837e6c9b39d4e1dfcbe93183';
      final response = await http.get(Uri.parse(url));
      if (response.statusCode >= 400) {
        throw 'Request to fetch weather data failed';
      }
      final json = jsonDecode(response.body);
      return json;
    } on Exception catch (e) {
      print(e);
      throw 'Unable to fetch data from server.';
    }
  }

  late Future<Map<String, dynamic>> weatherFuture;
  @override
  void initState() {
    super.initState();
    weatherFuture = fetchWeatherData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Weather Morning'),
        actions: [
          IconButton(
              onPressed: () {
                setState(() {
                  weatherFuture = fetchWeatherData();
                });
              },
              icon: const Icon(Icons.refresh))
        ],
      ),
      body: FutureBuilder(
        future: weatherFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator()); // Center
          }
          if (snapshot.hasError) {
            return Center(
              child: Text(snapshot.error.toString()),
            );
          }
          if (!snapshot.hasData) {
            return Center(
              child: Text('No data available'),
            );
          }
          print(snapshot.data);
          Map<String, dynamic> data = snapshot.data!;
          double currentTemperature = data['list'][0]['main']['temp'];
          int humidity = data['list'][0]['main']['humidity'];
          int pressure = data['list'][0]['main']['pressure'];
          double windSpeed = data['list'][0]['wind']['speed'];
          String weatherType = data['list'][0]['weather'][0]['main'];
          IconData icon = weatherType == 'Clouds' || weatherType == 'Rain'
              ? Icons.cloud
              : Icons.sunny;
          List<dynamic> weatherForecast = data['list'];
          weatherForecast.removeAt(0);

          return Container(
            padding: const EdgeInsets.all(16),
            width: double.infinity,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: double.infinity,
                  child: Card(
                    elevation: 6,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Padding(
                      padding: EdgeInsets.all(16.0),
                      child: Column(
                        children: [
                          Text(
                            '$currentTemperature  °C',
                            style: TextStyle(fontSize: 36),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Icon(
                            icon,
                            size: 64,
                          ),
                          SizedBox(
                            height: 14,
                          ),
                          Text(weatherType, style: TextStyle(fontSize: 26)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                const Text('Weather Forecast',
                    style:
                        TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(
                  height: 10,
                ),
                SizedBox(
                  height: 140,
                  child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: weatherForecast.length,
                      itemBuilder: (context, index) {
                        return Container(
                          margin: const EdgeInsets.symmetric(horizontal: 2),
                          child: Card(
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 8),
                              child: Column(
                                children: [
                                  Text(
                                    DateFormat('dd MMM\nhh:mm a').format(
                                        DateTime.fromMillisecondsSinceEpoch(
                                            (weatherForecast[index]['dt']
                                                    as int) *
                                                1000)),
                                    style: TextStyle(fontSize: 16),
                                    textAlign: TextAlign.center,
                                  ),
                                  SizedBox(
                                    height: 8,
                                  ),
                                  Icon(
                                    weatherForecast[index]['weather'][0]
                                                    ['main'] ==
                                                'Clouds' ||
                                            weatherForecast[index]['weather'][0]
                                                    ['main'] ==
                                                'Rain'
                                        ? Icons.cloud
                                        : Icons.sunny,
                                  ),
                                  SizedBox(
                                    height: 8,
                                  ),
                                  Text(
                                    '${weatherForecast[index]['main']['temp'].toString()} °C',
                                    style: TextStyle(fontSize: 18),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      }),
                ),
                const SizedBox(
                  height: 16,
                ),
                const Text(
                  'Additional Information',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Myinfo(
                      icon: Icons.water_drop,
                      value: '$humidity',
                      labe: 'Humidity',
                    ),
                    Myinfo(
                      icon: Icons.air,
                      value: '$windSpeed',
                      labe: 'Wind',
                    ),
                    Myinfo(
                      icon: Icons.beach_access,
                      labe: 'Pressure',
                      value: '$pressure',
                    ),
                  ],
                )
              ],
            ),
          );
        },
      ),
    );
  }
}
