import 'package:flutter/material.dart';

class Myinfo extends StatelessWidget {
  const Myinfo(
      {required this.icon, required this.labe, required this.value, super.key});
  final String labe;
  final String value;
  final IconData icon;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(8),
      child: Column(
        children: [
          Icon(
            icon,
            size: 34,
          ),
          SizedBox(
            height: 8,
          ),
          Text(labe, style: TextStyle(fontSize: 16)),
          SizedBox(
            height: 2,
          ),
          Text(value.toString(), style: TextStyle(fontSize: 16))
        ],
      ),
    );
  }
}
