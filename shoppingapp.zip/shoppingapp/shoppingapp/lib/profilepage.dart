
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shoppingapp/login.dart';
import 'package:shoppingapp/primarybutton.dart';

class Profile_page extends StatefulWidget {
  const Profile_page({super.key});

  @override
  State<Profile_page> createState() => _Profile_pageState();
}

class _Profile_pageState extends State<Profile_page> {
  FirebaseFirestore db = FirebaseFirestore.instance;
  FirebaseAuth auth = FirebaseAuth.instance;
  late Stream<QuerySnapshot<Map<String, dynamic>>> dataStream;
  User? currentUser;

  @override
  void initState() {
    super.initState();
    currentUser = auth.currentUser!;
    if (currentUser != null) {
      dataStream = db
          .collection('orders')
          .where('user_id', isEqualTo: currentUser!.uid)
          .snapshots();
    }
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(
              30,
            ),
            child: Container(
              width: double.infinity,
              child: currentUser == null
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('You are currently not logged in'),
                        SizedBox(
                          width: 120,
                          child: PrimaryNutton(
                            onPressed: () async {
                              await Navigator.of(context).push(
                                  MaterialPageRoute(
                                      builder: (context) => mylogin()));
                              setState(() {
                                currentUser = auth.currentUser;
                              });
                            },
                            text: 'Login',
                          ),
                        ),
                      ],
                    )
                  : Column(
                      children: [
                        SizedBox(
                          height: 12,
                        ),
                        CircleAvatar(
                          radius: 38,
                          backgroundImage: AssetImage('assets/5.png'),
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        Text(
                          currentUser!.email!.toString(),
                          style: TextStyle(fontSize: 18),
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        SizedBox(
                          width: 120,
                          child: PrimaryNutton(
                            onPressed: () {
                              auth.signOut().then((value) {
                                setState(() {
                                  currentUser = null;
                                });
                              });
                            },
                            text: 'Logout',
                          ),
                        ),
                        SizedBox(
                          height: 28,
                        ),
                        Text(
                          'My Orders',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          height: 12,
                        ),
                        if (currentUser != null)
                          StreamBuilder(
                            stream: dataStream,
                            builder: (context, snapshot) {
                              if (snapshot.connectionState ==
                                  ConnectionState.waiting) {
                                return CircularProgressIndicator.adaptive();
                              }
                              if (snapshot.hasError) {
                                return Text(snapshot.error.toString());
                              }
                              if (!snapshot.hasData) {
                                return Text('No data available');
                              }
                              if (snapshot.data!.docs.isEmpty) {
                                return Text('No Previous orders');
                              }
                              return SizedBox(
                                //height: 120,
                                child: ListView.builder(
                                  itemCount: snapshot.data!.docs.length,
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder: (context, index) {
                                    DocumentSnapshot order =
                                        snapshot.data!.docs[index];
                                    List<dynamic> products = order['items'];
                                    double totalAmount = 0;
                                    for (int i = 0; i < products.length; i++) {
                                      totalAmount += products[i]['Price'];
                                    }
                                    return Card(
                                      child: Padding(
                                        padding: const EdgeInsets.all(12.0),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text('Order ID: ${order.id}'),
                                            //
                                            // Text(
                                            //   DateFormat(
                                            //           'dd MMM, yyyy hh:mm a')
                                            //       .format(
                                            //     DateTime
                                            //         .fromMillisecondsSinceEpoch(
                                            //       order['time'],
                                            //     ),
                                            //   ),
                                            // ), //time
                                            //
                                            Text(order['address']),
                                            Text(order['mobile_number']),
                                            // Text (order ['address']),
                                            Divider(),

                                            for (int i = 0;
                                                i < products.length;
                                                i++)
                                              Container(
                                                padding: EdgeInsets.all(8),
                                                child: Row(
                                                  children: [
                                                    Image.asset(
                                                      products[i]['imageURL'],
                                                      width: 50,
                                                      height: 50,
                                                    ),
                                                    SizedBox(
                                                      width: 16,
                                                    ),
                                                    Expanded(
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text(
                                                            products[i]
                                                                ['title'],
                                                            style: TextStyle(
                                                                fontSize: 16),
                                                          ),
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Text(
                                                                'Size: ${products[i]['size']}',
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        14),
                                                              ),
                                                              Text(
                                                                '\$: ${products[i]['Price']}',
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        14,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
// Row)
                                              ),
                                            const Divider(),
                                            Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.end,
                                                children: [
                                                  Text('Total: '),
                                                  Text('\$${totalAmount}',
                                                      style: TextStyle(
                                                          fontSize: 18,
                                                          fontWeight:
                                                              FontWeight.bold)),
                                                ])
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              );
                            },
                          ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
