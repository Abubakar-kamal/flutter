final products = [
  {
    'id': '0',
    'title': 'Women/Stylo Shoes',
    'Price': 47,
    'imageURL': 'assets/1.png',
    'company': 'Stylo',
    'sizes': [9, 10, 11, 12],
  },
  {
    'id': '1',
    'title': 'Men/Addidas Shoes',
    'Price': 47,
    'imageURL': 'assets/3.png',
    'company': 'Addidas',
    'sizes': [9, 10, 11, 12],
  },
  {
    'id': '2',
    'title': 'Women/Bata Shoes',
    'Price': 47,
    'imageURL': 'assets/4.png',
    'company': 'Bata',
    'sizes': [9, 10, 11, 12],
  },
  {
    'id': '3',
    'title': 'Men/Nike Shoes',
    'Price': 45,
    'imageURL': 'assets/2.png',
    'company': 'Nike',
    'sizes': [9, 10, 11, 12],
  },
];
