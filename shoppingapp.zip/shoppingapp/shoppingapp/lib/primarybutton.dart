import 'package:flutter/material.dart';

class PrimaryNutton extends StatefulWidget {
  final String text;
  final onPressed;
  const PrimaryNutton({super.key, required this.text, this.onPressed});

  @override
  State<PrimaryNutton> createState() => _PrimaryNuttonState();
}

class _PrimaryNuttonState extends State<PrimaryNutton> {
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: widget.onPressed,
      child: Text(widget.text ),
    );
  }
}
