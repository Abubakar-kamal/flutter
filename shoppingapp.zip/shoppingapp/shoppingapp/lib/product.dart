import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'package:shoppingapp/productdetail.dart';

class productlistpage extends StatefulWidget {
  const productlistpage({super.key});

  @override
  State<productlistpage> createState() => _productlistpageState();
}

class _productlistpageState extends State<productlistpage> {
  final List<String> companies = ['All', 'Addidas', 'Nike', 'Bata', 'Stylo'];
  //List<Map<String, dynamic>> filteredProducts = products;
  FirebaseFirestore db = FirebaseFirestore.instance;
  late Stream<QuerySnapshot<Map<String, dynamic>>> dataStream;
  final textfieldborder = OutlineInputBorder(
      borderSide: const BorderSide(
        color: Colors.black54,
        width: 2,
      ),
      borderRadius: BorderRadius.circular(40));
  late String slectedcompany;
  @override
  void initState() {
    super.initState();
    slectedcompany = companies[0];
    dataStream = db.collection("products").snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Column(
        children: [
          Row(
            children: [
              const Text(
                'Shoes\nCollection',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
              Expanded(
                  child: TextField(
                onChanged: (value) {
                  String searchTerm = value.trim().toLowerCase();
                  setState(() {
                    if (searchTerm.isEmpty) {
                      dataStream = db.collection('products').snapshots();
                    } else {
                      dataStream = db
                          .collection('products')
                          .where('company', isEqualTo: slectedcompany)
                          .snapshots();
                    }
                    // if (value.trim().isEmpty) {
                    //   filteredProducts = products;
                    // } else {
                    //   filteredProducts = products
                    //       .where((element) =>
                    //           element['title']
                    //               .toString()
                    //               .toLowerCase()
                    //               .contains(searchTerm) ||
                    //           element['compamny']
                    //               .toString()
                    //               .toLowerCase()
                    //               .contains(searchTerm))
                    //       .toList();
                    // }
                  });
                },
                decoration: InputDecoration(
                  hintText: 'Search',
                  prefixIcon: const Icon(Icons.search),
                  border: textfieldborder,
                  enabledBorder: textfieldborder,
                ),
              ))
            ],
          ),
          const SizedBox(
            height: 20,
          ),
          SizedBox(
            height: 50,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: companies.length,
              itemBuilder: (context, index) {
                return Container(
                  margin: const EdgeInsets.only(right: 12),
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        slectedcompany = companies[index];
                        setState(() {
                          if (slectedcompany == "All") {
                            dataStream = db.collection('products').snapshots();
                          } else {
                            dataStream = db
                                .collection('products')
                                .where('company', isEqualTo: slectedcompany)
                                .snapshots();
                          }
                          // slectedcompany = companies[index];
                          // if (slectedcompany == 'All') {
                          //   filteredProducts = products;
                          // } else {
                          //   filteredProducts = products
                          //       .where((element) =>
                          //           element['company'] == slectedcompany)
                          //       .toList();
                          // }
                        });
                      });
                    },
                    child: Chip(
                      side: BorderSide(
                        color: slectedcompany == companies[index]
                            ? Colors.yellow
                            : const Color.fromARGB(255, 197, 229, 255),
                      ),
                      backgroundColor: slectedcompany == companies[index]
                          ? Colors.yellow
                          : const Color.fromARGB(255, 197, 229, 255),
                      label: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 2, vertical: 1),
                        child: Text(
                          companies[index],
                          style: const TextStyle(fontSize: 15),
                        ),
                      ),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Expanded(
              child: StreamBuilder(
            stream: dataStream,
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return Center(
                  child: Text('Please Wait'),
                );
              }

              return ListView.builder(
                shrinkWrap: true,
                itemCount: snapshot.data!.docs.length,
                itemBuilder: (context, index) {
                  DocumentSnapshot products = snapshot.data!.docs[index];

                  return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: Card(
                      color: index.isEven ? Colors.blue.shade50 : Colors.white,
                      surfaceTintColor: Colors.white,
                      elevation: 4,
                      child: GestureDetector(
                        onTap: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => PdETAIL(
                                  product: products.data()
                                      as Map<String, dynamic>)));
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                //  filteredProducts[index]['title'].toString(),
                                products['title'].toString(),

                                style: const TextStyle(
                                    fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Text(
                                //'\$${filteredProducts[index]['Price'].toString()}',
                                '\$${products['Price'].toString()}',

                                style: const TextStyle(
                                    fontWeight: FontWeight.w400, fontSize: 20),
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Hero(
                                tag:
                                    //'product-image-${filteredProducts[index]['id']}',
                                    'product-image-${products['id']}',
                                child: Image.asset(
                                    products['imageURL'].toString()),
                                // Image.asset(filteredProducts[index]
                                //     ['imageURL']
                                // .toString()),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ))
        ],
      ),
    );
  }
}
