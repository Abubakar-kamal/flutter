import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shoppingapp/cart_provide.dart';
import 'package:shoppingapp/checkout.dart';
import 'package:shoppingapp/login.dart';

class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('cart'),
        actions: context.watch<cartProvide>().cartList.isEmpty
            ? []
            : [
                TextButton(
                  style: TextButton.styleFrom(foregroundColor: Colors.black87),
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text('Confirmation'),
                        content: const Text(
                            'Do you want to remove this product from cart'),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: const Text('No'),
                            style: TextButton.styleFrom(
                                foregroundColor: Colors.blue),
                          ),
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                              context.read<cartProvide>().clearCart();
                            },
                            child: const Text('Yes'),
                            style: TextButton.styleFrom(
                                foregroundColor: Colors.red),
                          )
                        ],
                      ),
                    );
                  },
                  child: const Text(
                    "Clear Cart",
                  ),
                ),
              ],
      ),
      body: context.watch<cartProvide>().cartList.isEmpty
          ? const Center(
              child: Text("Cart is Empty"),
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                      itemCount: context.watch<cartProvide>().cartList.length,
                      itemBuilder: (context, index) {
                        final product =
                            context.watch<cartProvide>().cartList[index];
                        return Dismissible(
                          key: UniqueKey(),
                          onDismissed: (direction) {
                            context.read<cartProvide>().removeProduct(product);
                          },
                          background: Container(
                            color: Colors.red,
                          ),
                          confirmDismiss: (direction) {
                            return showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                title: const Text('Confirmation'),
                                content: const Text(
                                    'Do you want to remove this product from cart'),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop(false);
                                    },
                                    child: const Text('No'),
                                    style: TextButton.styleFrom(
                                        foregroundColor: Colors.blue),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop(true);
                                      context
                                          .read<cartProvide>()
                                          .removeProduct(product);
                                    },
                                    child: const Text('Yes'),
                                    style: TextButton.styleFrom(
                                        foregroundColor: Colors.red),
                                  )
                                ],
                              ),
                            );
                          },
                          child: Container(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 4),
                            child: Card(
                              elevation: 3,
                              child: ListTile(
                                leading: Image.asset(
                                  product['imageURL'],
                                  width: 70,
                                  height: 70,
                                ),
                                title: Text(product['title']),
                                subtitle: Text(
                                    'Size: ${product['size']},\n\$ ${product['Price']}'),
                                trailing: IconButton(
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      builder: (context) => AlertDialog(
                                        title: const Text('Confirmation'),
                                        content: const Text(
                                            'Do you want to remove this product from cart'),
                                        actions: [
                                          TextButton(
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                            child: const Text('No'),
                                            style: TextButton.styleFrom(
                                                foregroundColor: Colors.blue),
                                          ),
                                          TextButton(
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                              context
                                                  .read<cartProvide>()
                                                  .removeProduct(product);
                                            },
                                            child: const Text('Yes'),
                                            style: TextButton.styleFrom(
                                                foregroundColor: Colors.red),
                                          )
                                        ],
                                      ),
                                    );
                                  },
                                  icon: Icon(
                                    Icons.delete,
                                    color: Colors.red.shade700,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      }),
                ),
                Container(
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    color: Color.fromARGB(15, 223, 223, 18),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(28),
                      topLeft: Radius.circular(28),
                    ), // BoxDecoration
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        Text(
                          'Total: \$ ${getToBill()}',
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Theme.of(context)
                                  .colorScheme
                                  .primaryContainer,
                              foregroundColor: Colors.black87),
                          onPressed: () async {
                            FirebaseAuth auth = FirebaseAuth.instance;
                            User? currentUser = auth.currentUser;
                            if (currentUser == null) {
                              await Navigator.of(context).push(
                                MaterialPageRoute(
                                    builder: (context) => const mylogin()),
                              );
                              currentUser = auth.currentUser;
                              if (currentUser! != null) {
                                Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => const CheckoutPage(),
                                )); // MaterialPageRoute
                              }
                            } else {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => const CheckoutPage()));
                            }
                          },
                          icon: const Icon(Icons.check),
                          label: const Text(
                            'Proceed To Checkout',
                            style: TextStyle(
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ), //
              ],
            ),
    );
  }

  double getToBill() {
    double total = 0;
    final cartList = context.read<cartProvide>().cartList;
    // for (int i = 0; i < cartList.length; i++) {
    //   total = total + double.parse(cartList[i]['Price'].toString());
    // }
    cartList.forEach((element) {
      total = total + double.parse(element['Price'].toString());
    });
    return total;
  }
}
