import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shoppingapp/cart_provide.dart';
import 'package:shoppingapp/home.dart';

class OrdercState extends StatefulWidget {
  final String name;
  final String mobile;
  final String email;
  final String city;
  final String address;
  const OrdercState(
      {super.key,
      required this.name,
      required this.mobile,
      required this.email,
      required this.city,
      required this.address});

  @override
  State<OrdercState> createState() => _OrdercStateState();
}

class _OrdercStateState extends State<OrdercState> {
  @override
  Widget build(BuildContext context) {
    // ignore: deprecated_member_use
    return WillPopScope(
      onWillPop: () {
      c
      },
      child: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.check_circle,
                    size: 90,
                    color: Colors.green,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    'Thank YOU!',
                    style: TextStyle(fontSize: 26),
                  ),
                  SizedBox(
                    height: 2,
                  ),
                  Text(
                    widget.name,
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    'Your order will be delivered with 3 to 5 working days to city ${widget.city} at the adress "${widget.address}"',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          Theme.of(context).colorScheme.primaryContainer,
                      foregroundColor: Colors.black87,
                    ),
                    onPressed: () {
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (context) => MyHomePage()),
                          (route) => false);
                      context.read<cartProvide>().clearCart();
                    },
                    child: const Text(
                      'Go To Home Page Order',
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
