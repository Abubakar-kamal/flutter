import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shoppingapp/cart_provide.dart';

class PdETAIL extends StatefulWidget {
  final Map<String, dynamic> product;

  const PdETAIL({super.key, required this.product});

  @override
  State<PdETAIL> createState() => _PdETAILState();
}

class _PdETAILState extends State<PdETAIL> {
  late int selectedsize;

  @override
  void initState() {
    super.initState();
    selectedsize = (widget.product['sizes'] as List<dynamic>)[0];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Details'),
      ),
      body: Column(
        children: [
          Text(
            widget.product['title'],
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          Spacer(),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Hero(
              tag: 'product-image',
              child: Image.asset(
                widget.product['imageURL'].toString(),
              ),
            ),
          ),
          Spacer(),
          Container(
            decoration: BoxDecoration(
                color: Color(0xFFF0F0F0),
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(28),
                    topRight: Radius.circular(28))),
            width: double.infinity,
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  Text(
                    '\$${widget.product['Price']}',
                    style: TextStyle(fontSize: 24),
                  ),
                  SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                    height: 50,
                    child: ListView.builder(
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      itemCount:
                          (widget.product['sizes'] as List<dynamic>).length,
                      itemBuilder: (context, index) {
                        return Container(
                          margin: EdgeInsets.symmetric(horizontal: 4),
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                selectedsize = (widget.product['sizes']
                                    as List<dynamic>)[index];
                              });
                            },
                            child: Chip(
                                backgroundColor: selectedsize ==
                                        (widget.product['sizes']
                                            as List<dynamic>)[index]
                                    ? Theme.of(context)
                                        .colorScheme
                                        .primaryContainer
                                    : null,
                                label: Text((widget.product['sizes']
                                        as List<dynamic>)[index]
                                    .toString())),
                          ),
                        );
                      },
                    ),
                  ),
                  SizedBox(
                    height: 16,
                  ),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                        backgroundColor:
                            Theme.of(context).colorScheme.primaryContainer,
                        foregroundColor: Colors.black87),
                    onPressed: () {
                      widget.product['size'] = selectedsize;
                      context.read<cartProvide>().addProduct(widget.product);
                      Navigator.of(context).pop();
                    },
                    icon: Icon(Icons.shopping_cart),
                    label: Text('Add To Cart'),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
