import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shoppingapp/passwordtextfeild.dart';
import 'package:shoppingapp/signup.dart';

class mylogin extends StatefulWidget {
  const mylogin({super.key});

  @override
  State<mylogin> createState() => _myloginState();
}

class _myloginState extends State<mylogin> {
  String email = '';
  String pass = '';
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final GlobalKey<FormState> _formkey = GlobalKey();
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: SafeArea(
            child: Container(
              padding: EdgeInsets.all(24),
              child: Form(
                key: _formkey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 20.0),
                      child: Image.asset(
                        'assets/5.png',
                        height: 100,
                      ),
                    ),
                    Text(
                      'Welcome back ',
                      style: TextStyle(
                        fontSize: 20,
                        color: Theme
                            .of(context)
                            .colorScheme
                            .primaryContainer,
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      'Sign in to continue',
                      style: TextStyle(
                        fontSize: 14,
                        color: Theme
                            .of(context)
                            .colorScheme
                            .primaryContainer,
                      ),
                    ),
                    SizedBox(
                      height: 40,
                    ),
                    TextFormField(
                      validator: (value) =>
                      value == null || value.isEmpty
                          ? 'Email is required'
                          : null,

                      controller: emailController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        filled: true,
                        prefixIcon: CircleAvatar(
                          child: Icon(
                            Icons.email,
                            color: Theme
                                .of(context)
                                .colorScheme
                                .primaryContainer,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Password_feild(
                      passwordController: passwordController,
                      hint: 'Enter your password',
                      label: 'Password',
                      validator: (value) =>
                      value == null || value.isEmpty
                          ? 'Password is required'
                          : null,
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        style: TextButton.styleFrom(
                          foregroundColor:
                          Theme
                              .of(context)
                              .colorScheme
                              .primaryContainer,
                        ),
                        onPressed: () {},
                        child: Text(
                          'Forgot Password',
                        ),
                      ),
                    ),
                    Container(
                      //  color: Colors.purple,
                        width: double.infinity,
                        margin: EdgeInsets.only(top: 24),
                        child: isLoading
                            ? const Center(
                            child: CircularProgressIndicator.adaptive())
                            : ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                            Theme
                                .of(context)
                                .colorScheme
                                .primaryContainer,
                          ),
                          onPressed: () async {
                            if (_formkey.currentState!.validate()) {
                              String email = emailController.text;
                              String password = passwordController.text;
                              setState(() {
                                isLoading = true;
                              });
                              try {
                                await FirebaseAuth.instance
                                    .signInWithEmailAndPassword(
                                    email: email, password: password);
                                ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                        content: Text('Login suucessfull')));
                                Navigator.of(context).pop();
                              } on FirebaseAuthException catch (e) {
                                String errorCode = e.code;

                                print(errorCode);

                                if (e.code == 'invalid-credential') {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(content: Text(
                                          'Invalid Username & password')));
                                      } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Error: ${e.code}')));
                                  }
                                  } catch (e)
                                  {
                                    print(e);
                                  } finally {
                                setState(() {
                                  isLoading = false;
                                });
                              }
                            }
                          },
                          child: Text(
                            'Login',
                            style: TextStyle(fontSize: 20),
                          ),
                        )),
                    SizedBox(height: 32,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Don't have an account?"),
                        TextButton (
                            onPressed: () async {
                              await Navigator.of (context) .push (MaterialPageRoute(
                                  builder: (context) => mySignup(), )); // MaterialPageRoute
                              User? currentUser = FirebaseAuth.instance.currentUser;
                              if(currentUser != null) {
                              Navigator.of (context).pop () ;
                              }
                            },
                            child: Text("Signup")),
                      ],
                    ),
                  ],
                ),
              ),
            )),
      ),
      
    );
  }
}
