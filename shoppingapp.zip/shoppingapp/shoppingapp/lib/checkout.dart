import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shoppingapp/cart_provide.dart';
import 'package:shoppingapp/confirm.dart';

class CheckoutPage extends StatefulWidget {
  const CheckoutPage({super.key});

  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  final cities = [
    'Multan',
    "Lahore",
    'Islamabad',
    'Karachi',
    'Peshawar',
    'Quetta',
  ];
  String? selectedCity;
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  TextEditingController nameController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  FirebaseFirestore db = FirebaseFirestore.instance;
  bool isLoading = false;
  User? currentUser;

  @override
  void initState() {
    super.initState();
    currentUser = FirebaseAuth.instance.currentUser;

    if (currentUser != null) {
      emailController.text = currentUser!.email!;
    }
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Checkout', style: TextStyle(fontSize: 16)),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextFormField(
                  keyboardType: TextInputType.name,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "Please enter your name";
                    } else {
                      return null;
                    }
                  },
                  controller: nameController,
                  decoration: InputDecoration(
                    hintText: "Enter your Name",
                    labelText: 'Full Name',
                    floatingLabelBehavior: FloatingLabelBehavior.always,
                    floatingLabelStyle:
                        TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    icon: CircleAvatar(
                      backgroundColor: Colors.grey.shade200,
                      child: Icon(
                        Icons.person,
                        size: 28,
                      ),
                    ),
                  ), // InputDecoration
                ),
                const SizedBox(
                  height: 16,
                ),
                TextFormField(
                  keyboardType: TextInputType.number,
                  controller: mobileController,
                  validator: (value) => value == null || value.isEmpty
                      ? "Please enter mobile number"
                      : null,
                  decoration: InputDecoration(
                    hintText: "Enter your Phone Number",
                    labelText: 'Mobile Number',
                    floatingLabelBehavior: FloatingLabelBehavior.always,
                    labelStyle:
                        TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    floatingLabelStyle:
                        TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    icon: CircleAvatar(
                      backgroundColor: Colors.grey.shade200,
                      child: Icon(
                        Icons.phone_android,
                        size: 28,
                      ),
                    ),
                  ), // InputDecoration
                ),
                const SizedBox(
                  height: 16,
                ),
                TextFormField(
                  controller: emailController,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return null;
                    } else {
                      if (value.contains("@") && value.contains(".")) {
                        return null;
                      } else {
                        return "Enter valid email address";
                      }
                    }
                  },
                  keyboardType: TextInputType.emailAddress,
                  readOnly: true,
                  decoration: InputDecoration(
                    hintText: "Enter your Email Address",
                    labelText: 'Email Address (optional)',
                    floatingLabelBehavior: FloatingLabelBehavior.always,
                    labelStyle:
                        TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    floatingLabelStyle:
                        TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    icon: CircleAvatar(
                      backgroundColor: Colors.grey.shade200,
                      child: Icon(
                        Icons.email,
                        size: 28,
                      ),
                    ),
                  ), // InputDecoration
                ),
                const SizedBox(
                  height: 16,
                ),
                TextFormField(
                  controller: addressController,
                  validator: (value) => value == null || value.isEmpty
                      ? 'Please enter address for delivery'
                      : null,
                  decoration: InputDecoration(
                    hintText: "House No./Building No., Street, Area",
                    labelText: 'Address',
                    floatingLabelBehavior: FloatingLabelBehavior.always,
                    labelStyle:
                        TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    floatingLabelStyle:
                        TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    icon: CircleAvatar(
                      backgroundColor: Colors.grey.shade200,
                      child: Icon(
                        Icons.location_city,
                        size: 28,
                      ),
                    ),
                  ), // InputDecoration
                ),
                const SizedBox(
                  height: 16,
                ),
                DropdownButtonFormField(
                    validator: (value) =>
                        value == null ? 'Please select city' : null,
                    decoration: InputDecoration(
                        floatingLabelBehavior: FloatingLabelBehavior.always,
                        labelStyle: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                        floatingLabelStyle: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                        labelText: 'Location',
                        icon: CircleAvatar(
                            backgroundColor: Colors.grey.shade200,
                            child: Icon(Icons.location_pin))),
                    hint: Text('Select City'),
                    isExpanded: true,
                    value: selectedCity,
                    items: cities
                        .map(
                          (e) => DropdownMenuItem(
                            child: Text(e),
                            value: e,
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedCity = value;
                      });
                    }),
                const SizedBox(
                  height: 32,
                ),
                isLoading
                    ? Center(
                        child: CircularProgressIndicator(),
                      )
                    : ElevatedButton(
                        onPressed: () {
                          if (currentUser == null) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                content:
                                    Text('Unable to get user information!')));
                            return;
                          }

                          if (formKey.currentState!.validate()) {
                            String name = nameController.text.trim();
                            String mobile = mobileController.text.trim();
                            String email = emailController.text.trim();
                            String address = addressController.text.trim();
                            setState(() {
                              isLoading = true;
                            });
                            db.collection('orders').add({
                              'name': name,
                              'mobile_number': mobile,
                              'address': address,
                              'email': email,
                              'user_id': currentUser!.uid,
                              'status': "Pending",
                              'time': DateTime.now().millisecondsSinceEpoch,
                              'items': context.read<cartProvide>().cartList
                            }).then((value) {
                              setState(() {
                                isLoading = false;
                              });
                              context.read<cartProvide>().clearCart();
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => OrdercState(
                                      name: name,
                                      mobile: mobile,
                                      email: email,
                                      city: selectedCity!,
                                      address: address)));
                            }).onError((error, stackTrace) {
                              setState(() {
                                isLoading = false;
                              });
                              ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                      content: Text('Something went wrong!')));
                              print(error);
                              print(stackTrace);
                            });
                          }
                        },
                        child: const Text('Place Order'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor:
                              Theme.of(context).colorScheme.primaryContainer,
                          foregroundColor: Colors.black87,
                          minimumSize: const Size(double.infinity, 50),
                        ),
                      ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
