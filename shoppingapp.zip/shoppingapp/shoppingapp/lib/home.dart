import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shoppingapp/cart.dart';
import 'package:shoppingapp/cart_provide.dart';
import 'package:shoppingapp/product.dart';
import 'package:shoppingapp/profilepage.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final pages = [
    const productlistpage(),
    const CartPage(),
    const Profile_page(),
  ];
  int currentpage = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[currentpage]),
      bottomNavigationBar:
      NavigationBar(
        selectedIndex: currentpage,
        destinations: [
          NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(
              icon: Stack(
                children: [
                  Container(
                    margin: EdgeInsets.all(8),
                    child: Icon(Icons.shopping_cart),
                  ),
                  Positioned(
                    right: 0,
                    top: 0,
                    child: Container(

                      height: 20,
                      width: 20,
                      decoration: BoxDecoration(

                          color: Colors.red,
                          borderRadius: BorderRadius.circular(100)),
                      child: Center(
                        child: Text(
                          context
                              .watch<cartProvide>()
                              .cartList
                              .length
                              .toString(),
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              label: 'Cart'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profile'),
        ],
        onDestinationSelected: (value) {
          setState(() {
            currentpage = value;
          });
        },
        //selectedItemColor: Theme.of(context).colorScheme.primaryContainer,
      ),
    );
  }
}
