import 'package:flutter/material.dart';

class Password_feild extends StatefulWidget {
  final String hint;
  final String label;
  final TextEditingController passwordController;
  String? Function(String?)? validator;

  Password_feild(
      {super.key,
      required this.hint,
      required this.label,
      this.validator,
      required this.passwordController});

  @override
  State<Password_feild> createState() => _Password_feildState();
}

class _Password_feildState extends State<Password_feild> {
  bool _passwordVisible = true;
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: widget.passwordController,
      validator: widget.validator,
      obscureText: _passwordVisible,
      decoration: InputDecoration(
          labelText: widget.label,
          filled: true,
          hintText: widget.hint,
          suffixIcon: IconButton(
              onPressed: () {
                setState(() {
                  _passwordVisible = !_passwordVisible;
                });
              },
              icon: CircleAvatar(
                child: Icon(
                    !_passwordVisible ? Icons.visibility : Icons.visibility_off,
                    color: Colors.grey),
              )),
          prefixIcon: Icon(Icons.password, color: Colors.grey)),
    );
  }
}
