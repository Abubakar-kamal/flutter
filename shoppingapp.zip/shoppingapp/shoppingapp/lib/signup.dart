import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shoppingapp/home.dart';
import 'package:shoppingapp/passwordtextfeild.dart';

class mySignup extends StatefulWidget {
  const mySignup({super.key});

  @override
  State<mySignup> createState() => _mySignupState();
}

class _mySignupState extends State<mySignup> {
  String email = '';
  String pass = '';
  final emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final GlobalKey<FormState> _formkey = GlobalKey();
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: SafeArea(
            child: Container(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formkey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 20.0),
                  child: Image.asset(
                    'assets/5.png',
                    height: 100,
                  ),
                ),
                Text(
                  'Welcome back ',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.brown,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Text(
                  'Create Your new account',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(
                  height: 40,
                ),
                TextFormField(
                  controller: emailController,
                  validator: (value) => value == null || value.isEmpty
                      ? 'Email is required'
                      : null,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                      labelText: 'Email',
                      filled: true,
                      prefixIcon: CircleAvatar(
                        child: Icon(
                          Icons.email,
                          color: Colors.grey,
                        ),
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),
                Password_feild(
                  passwordController: passwordController,
                  hint: 'Enter your password',
                  label: 'Password',
                  validator: (value) => value == null || value.isEmpty
                      ? 'Password is required'
                      : null,
                ),
                Container(
                    //  color: Colors.purple,
                    width: double.infinity,
                    margin: const EdgeInsets.only(top: 24),
                    child: isLoading
                        ? const Center(
                            child: CircularProgressIndicator.adaptive())
                        : ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Theme.of(context)
                                  .colorScheme
                                  .primaryContainer,
                            ),
                            onPressed: () async {
                              if (_formkey.currentState!.validate()) {
                                String email = emailController.text;
                                String password = passwordController.text;
                                try {
                                  setState(() {
                                    isLoading = true;
                                  });
                                  await FirebaseAuth.instance
                                      .createUserWithEmailAndPassword(
                                    email: email,
                                    password: password,
                                  );
                                  setState(() {
                                    isLoading = false;
                                  });
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                          content:
                                              Text('Signup Successfully.')));
                                  Navigator.of(context).pop();
                                  //  Navigator.of(context).push(MaterialPageRoute(builder: (context)=>MyHomePage()));
                                  setState(() {
                                    isLoading = false;
                                  });
                                } on FirebaseAuthException catch (e) {
                                  setState(() {
                                    isLoading = false;
                                  });
                                  if (e.code == 'weak-password') {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(
                                            content: Text(
                                                'The password provided is too weak.')));
                                  } else if (e.code == 'email-already-in-use') {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(
                                            content: Text(
                                                'The account already exists for that email.')));
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                            content: Text('Error: ${e.code}')));
                                  }
                                } catch (e) {
                                  setState(() {
                                    isLoading = false;
                                  });
                                  print(e);
                                }
                              }
                            },
                            child: const Text(
                              'Signup',
                              style: TextStyle(fontSize: 20),
                            ),
                          ))
              ],
            ),
          ),
        )),
      ),
    );
  }
}
