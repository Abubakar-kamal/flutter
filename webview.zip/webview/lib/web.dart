import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  WebViewController webviewController = WebViewController();
  int loading = 0;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    webviewController.setNavigationDelegate(NavigationDelegate(
      onPageStarted: (url) {
        loading = 0;
      },
      onPageFinished: (url) {
        loading = 100;
      },
      onProgress: (progress) {
        setState(() {
          loading = progress;
        });
      },
    ));
    webviewController.setJavaScriptMode(JavaScriptMode.unrestricted);
    webviewController
        .loadRequest(Uri.parse('https://en.wikipedia.org/wiki/Blog'));
  }

  @override
  Widget build(BuildContext context) {
    // ignore: deprecated_member_use
    return WillPopScope(
      onWillPop: () async {
        if (await webviewController.canGoBack()) {
          webviewController.goBack();
          return Future(() => false);
        }
        return Future(() => true);
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.green,
          title: Text('WebView'),
          actions: [
            IconButton(
                onPressed: () async {
                  if (await webviewController.canGoBack()) {
                    webviewController.goBack();
                  }
                },
                icon: Icon(Icons.chevron_left)), // IconButton
            IconButton(
                onPressed: () async {
                  if (await webviewController.canGoForward()) {
                    webviewController.goForward();
                  }
                },
                icon: Icon(Icons.chevron_right)),
            //IconButton
            IconButton(
                onPressed: () {
                  webviewController.reload();
                },
                icon: Icon(Icons.refresh))
          ],
        ),
        body: Stack(
          children: [
            WebViewWidget(
              controller: webviewController,
            ),
            if (loading < 100)
              LinearProgressIndicator(
                value: loading.toDouble(),
                color: Colors.amber,
              ),
          ],
        ),
      ),
    );
  }
}
